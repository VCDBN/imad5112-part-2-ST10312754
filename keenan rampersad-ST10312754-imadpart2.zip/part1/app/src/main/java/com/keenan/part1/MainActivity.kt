package com.keenan.part1

package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    lateinit var display: TextView
    lateinit var edit_first: EditText
    lateinit var edit_second: EditText
    lateinit var add: Button
    lateinit var sub: Button
    lateinit var multiply: Button
    lateinit var div: Button
    lateinit var sqrtBtn: Button
    lateinit var powerBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.display_result)
        edit_first = findViewById(R.id.edit_first)
        edit_second = findViewById(R.id.edit_second)
        add = findViewById(R.id.add)
        sub = findViewById(R.id.subtract)
        multiply = findViewById(R.id.multiply)
        div = findViewById(R.id.divide)
        sqrtBtn = findViewById(R.id.sqrt)
        powerBtn = findViewById(R.id.power)

        add.setOnClickListener { performOperation(Operation.ADD) }
        sub.setOnClickListener { performOperation(Operation.SUBTRACT) }
        multiply.setOnClickListener { performOperation(Operation.MULTIPLY) }
        div.setOnClickListener { performOperation(Operation.DIVIDE) }
        sqrtBtn.setOnClickListener { performOperation(Operation.SQRT) }
        powerBtn.setOnClickListener { performOperation(Operation.POWER) }
    }

    private fun performOperation(operation: Operation) {
        val res1 = edit_first.text.toString().toDoubleOrNull() ?: 0.0
        val res2 = edit_second.text.toString().toDoubleOrNull() ?: 0.0

        val result = when (operation) {
            Operation.ADD -> res1 + res2
            Operation.SUBTRACT -> res1 - res2
            Operation.MULTIPLY -> res1 * res2
            Operation.DIVIDE -> if (res2 != 0.0) res1 / res2 else Double.NaN
            Operation.SQRT -> if (res1 >= 0) sqrt(res1) else complexSqrt(res1)
            Operation.POWER -> res1.pow(res2)
        }

        display.text = formatResult(operation, result)
    }

    private fun complexSqrt(number: Double): String {
        val absValue = sqrt(-number)
        return "${String.format("%.2f", absValue)}i"
    }

    private fun formatResult(operation: Operation, result: Double): String {
        return when (operation) {
            Operation.DIVIDE -> if (result.isNaN()) "Error: Division by 0" else result.toString()
            Operation.SQRT -> "sqrt(${String.format("%.2f", result)})"
            Operation.POWER -> "${edit_first.text}^${edit_second.text} = ${String.format("%.2f", result)}"
            else -> result.toString()
        }
    }

    enum class Operation {
        ADD, SUBTRACT, MULTIPLY, DIVIDE, SQRT, POWER
    }
}


